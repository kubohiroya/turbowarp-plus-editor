import {isRemoteSource, LoaderError, validateManifest, type ExecutionMode, type ExtensionSpec, type FetchPort, type FetchResult,
    type LoaderOptions, type LoaderPorts, type Manifest, type ReadOptions} from './index.js';
import {createProjectIO, type ArchiveLimits, type ZipConstructor} from './project-codec.js';
import {readPreparedProject} from './project-data.js';
import {collectVerifiedCodes} from './verified-code.js';
import {DEFAULT_LOADER_LIMITS} from './limits.js';
import {markFetchRejection} from './fetch-rejection.js';

export type ExtensionAdditionRequest = {
    id: string;
    execution?: ExecutionMode;
    source: {type: 'embedded-file'; path?: string};
    bytes: Uint8Array | Blob;
} | {
    id: string;
    execution?: ExecutionMode;
    source: {type: 'remote-non-cacheable' | 'remote-cacheable'; url: string};
    bytes?: never;
};
export type AuthoringPorts = Pick<LoaderPorts, 'fetcher' | 'trustProvider' | 'cache' | 'diagnostics'>;
export interface ExtensionAdditionOptions {
    zip: ZipConstructor;
    signal?: AbortSignal;
    loaderOptions?: LoaderOptions;
    archiveOptions?: ArchiveLimits;
    /**
     * The address to give this project, or nothing to keep the one it has.
     *
     * Whether to assign one is the host's call, not this function's: only the host knows whether
     * the author chose an address or whether this is a first save that needs a default. So this
     * sets what it is given and leaves the existing address alone when it is given nothing —
     * `readProjectAuthoringState` reports what a project already carries, so the host can tell
     * the two apart before deciding.
     */
    uri?: string;
}
export interface PreparedExtensionAddition {
    readonly projectBytes: Uint8Array;
    readonly spec: ExtensionSpec;
    readonly manifest: Manifest;
}

const encoder = new TextEncoder();
function fail(code: string, message: string, id?: string): never { throw new LoaderError(code, message, id); }
const plainObject = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === 'object' && !Array.isArray(value) &&
    Object.getPrototypeOf(value) === Object.prototype;
const digest = async (bytes: BufferSource) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
    byte => byte.toString(16).padStart(2, '0')).join('');

function snapshotProject(input: unknown): unknown {
    if (input instanceof Uint8Array) return new Uint8Array(input);
    if (input instanceof ArrayBuffer) return input.slice(0);
    if (typeof input === 'string' || input instanceof Blob) return input;
    return JSON.stringify(input);
}

/** Computes SHA-256 and reviews the candidate without executing code or changing the input. */
export function prepareExtensionAddition(input: unknown, request: ExtensionAdditionRequest,
    ports: AuthoringPorts, options: ExtensionAdditionOptions): Promise<PreparedExtensionAddition>;
/**
 * Add a file-backed Embedded or URL-backed Remote extension without evaluating it.
 * A host approval is required before the candidate is returned; the original is untouched.
 */
export async function prepareExtensionAddition(input: unknown, request: unknown, ports: AuthoringPorts, {
    zip: Zip, signal: externalSignal, loaderOptions = {}, archiveOptions, uri
}: Partial<ExtensionAdditionOptions> = {}): Promise<PreparedExtensionAddition> {
    if (typeof Zip !== 'function' || typeof Zip.loadAsync !== 'function') throw new TypeError('A compatible JSZip constructor is required');
    if (!plainObject(request) || Object.keys(request).some(key => !['id', 'source', 'bytes', 'execution'].includes(key))) {
        fail('INVALID_ADDITION', 'An extension ID and file or URL source are required');
    }
    if (typeof ports?.trustProvider?.authorize !== 'function') fail('INVALID_PORT', 'An explicit host trust provider is required');
    const limits = {maxBytes: DEFAULT_LOADER_LIMITS.maxBytes, timeoutMs: DEFAULT_LOADER_LIMITS.timeoutMs, ...loaderOptions};
    for (const key of ['maxBytes', 'maxTotalBytes', 'maxExtensions', 'timeoutMs'] as const) {
        const value = limits[key];
        if (value !== undefined && (!Number.isSafeInteger(value) || value < 1)) fail('INVALID_OPTIONS', `Invalid ${key}`);
    }
    const source = plainObject(request.source) && request.source.type === 'embedded-file' && request.source.path === undefined ?
        {...request.source, path: `extensions/${request.id}.js`} : request.source;
    // Reuse the runtime schema before any bytes are read or network requests begin.
    const draft = validateManifest({schemaVersion: 1, extensions: [{id: request.id, source,
        execution: request.execution === undefined ? 'unsandboxed' : request.execution,
        sha256: '0'.repeat(64)}]}, loaderOptions).extensions[0];
    if (isRemoteSource(draft.source) && request.bytes !== undefined) fail('INVALID_ADDITION', 'Remote sources must be fetched from their URL', draft.id);
    if (request.bytes instanceof Uint8Array && (request.bytes.byteLength < 1 || request.bytes.byteLength > limits.maxBytes)) {
        fail('INVALID_BYTES', 'Extension file is empty or exceeds the byte limit', draft.id);
    }
    const suppliedBytes = request.bytes instanceof Uint8Array ? new Uint8Array(request.bytes) : request.bytes;
    if (draft.source.type === 'embedded-file' && !(suppliedBytes instanceof Uint8Array) && !(suppliedBytes instanceof Blob)) {
        fail('INVALID_BYTES', 'Embedded additions require a JavaScript file', draft.id);
    }
    if (suppliedBytes instanceof Blob && (suppliedBytes.size < 1 || suppliedBytes.size > limits.maxBytes)) {
        fail('INVALID_BYTES', 'Extension file is empty or exceeds the byte limit', draft.id);
    }
    const controller = new AbortController();
    const abort = () => controller.abort(externalSignal!.reason);
    if (externalSignal?.aborted) abort();
    else externalSignal?.addEventListener('abort', abort, {once: true});
    const signal = controller.signal;
    const check = () => {
        if (signal.aborted) fail(signal.reason?.code === 'TIMEOUT' ? 'TIMEOUT' : 'CANCELLED', 'Extension addition interrupted', draft.id);
    };
    const wait = async <T>(task: () => T | PromiseLike<T>): Promise<T> => {
        check();
        let cancel!: () => void;
        const cancelled = new Promise<never>((_resolve, reject) => {
            cancel = () => { try { check(); } catch (error) { reject(error); } };
            signal.addEventListener('abort', cancel, {once: true});
        });
        try { return await Promise.race([Promise.resolve().then(task), cancelled]); }
        finally { signal.removeEventListener('abort', cancel); }
    };
    const timer = setTimeout(() => controller.abort(new LoaderError('TIMEOUT', 'Extension addition timed out')), limits.timeoutMs);
    try {
        const io = createProjectIO({zip: Zip, ...archiveOptions});
        const prepared = await wait(() => io.prepare(snapshotProject(input), {signal}));
        const {project, files} = await wait(() => readPreparedProject(prepared, io, Zip));
        if (project.extensions !== undefined && (!Array.isArray(project.extensions) || project.extensions.some(id => typeof id !== 'string'))) {
            fail('INVALID_PROJECT', 'Project extensions must be an ID array');
        }
        if (project.extensionURLs !== undefined && !plainObject(project.extensionURLs)) fail('INVALID_PROJECT', 'Project extensionURLs must be an object');
        const previous = prepared.manifest?.extensions || [];
        // Carried through every rebuild below: an address that changed when an extension was
        // added would not be an address. The host may set one, which is how a project gets its
        // first; saying nothing keeps what is there.
        const address = uri ?? prepared.manifest?.uri;
        const carried = address === undefined ? {} : {uri: address};
        if (previous.some(spec => spec.id === draft.id) || (project.extensions || []).includes(draft.id) ||
            Object.hasOwn(project.extensionURLs || {}, draft.id)) fail('DUPLICATE_EXTENSION', 'This extension ID already belongs to the project', draft.id);
        validateManifest({schemaVersion: 1, ...carried, extensions: [...previous, draft]}, loaderOptions);
        if (draft.source.type === 'embedded-file' && Object.hasOwn(files, draft.source.path)) {
            fail('SOURCE_PATH_COLLISION', 'The embedded path already exists in this project', draft.id);
        }
        let bytes: unknown;
        if (!isRemoteSource(draft.source)) {
            bytes = suppliedBytes instanceof Blob ? new Uint8Array(await wait(() => suppliedBytes.arrayBuffer())) : suppliedBytes;
        } else {
            const {url} = draft.source;
            if (typeof ports.fetcher?.fetch !== 'function') fail('INVALID_PORT', 'Remote fetch port is unavailable', draft.id);
            let response: FetchResult;
            try { response = await wait(() => ports.fetcher!.fetch(url, {signal, maxBytes: limits.maxBytes})); }
            catch (cause) {
                markFetchRejection(cause);
                if (cause instanceof LoaderError) throw cause;
                throw new LoaderError('LOAD_FAILED', 'Remote extension could not be fetched', draft.id, cause);
            }
            if (!response || !Array.isArray(response.redirects) || response.redirects.length || response.finalURL !== url) {
                fail('REDIRECT_DENIED', 'Unproven or redirected remote source', draft.id);
            }
            bytes = response.bytes;
        }
        if (!(bytes instanceof Uint8Array) || bytes.byteLength < 1 || bytes.byteLength > limits.maxBytes) {
            fail('INVALID_BYTES', 'Extension bytes are empty, oversized, or invalid', draft.id);
        }
        const verified = new Uint8Array(bytes);
        const sha256 = await wait(() => digest(verified));
        const manifest = validateManifest({schemaVersion: 1, ...carried, extensions: [...previous, {...draft, sha256}]}, loaderOptions);
        const spec = manifest.extensions.find(item => item.id === draft.id)!;
        project.turboWarpPlus = manifest;
        project.extensions = [...(project.extensions || []), spec.id];
        files['project.json'] = encoder.encode(JSON.stringify(project));
        if (spec.source.type === 'embedded-file') files[spec.source.path] = verified;
        const archive = new Zip();
        for (const [path, content] of Object.entries(files)) archive.file(path, content, {dir: path.endsWith('/'), createFolders: false});
        const projectBytes: Uint8Array = await wait(() => archive.generateAsync({type: 'uint8array', compression: 'STORE'}));
        const candidate = await wait(() => io.prepare(projectBytes, {signal}));
        io.activate(candidate.context);
        // Only the newly fetched URL is snapshotted. Other pinned sources keep the host's fetch policy.
        const pinned = spec.source;
        const fetcher: FetchPort | undefined = isRemoteSource(pinned) ? {
            fetch(url: string, options: ReadOptions) {
                if (url === pinned.url) return Promise.resolve({bytes: new Uint8Array(verified), finalURL: url, redirects: []});
                return ports.fetcher!.fetch(url, options);
            }
        } : ports.fetcher;
        await wait(() => collectVerifiedCodes(manifest, {...ports, fetcher, embeddedReader: io.embeddedReader}, loaderOptions, signal));
        check();
        return Object.freeze({projectBytes, spec, manifest});
    } finally {
        clearTimeout(timer);
        externalSignal?.removeEventListener('abort', abort);
    }
}

const UUIDV7 = /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Where an unchosen address is put, relative to whatever origin assigns it. */
export const PROJECT_URI_PREFIX = 'turbowarp-plus-projects';

/**
 * A fresh identifier for one project: a UUID version 7.
 *
 * Version 7 and not 4 because the first 48 bits are the millisecond clock, so the identifier
 * itself sorts by when the project was first saved, to the millisecond. That costs nothing over a
 * random UUID and leaves the ordering available to anything that wants it. Two identifiers made in
 * the same millisecond are ordered by their random bits, not by which came first.
 * @returns {string} The UUID, in the canonical lowercase form.
 */
export function createProjectUUID(): string {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    const time = Date.now();
    for (let index = 0; index < 6; index++) bytes[index] = (time / 2 ** (8 * (5 - index))) & 0xff;
    bytes[6] = 0x70 | (bytes[6]! & 0x0f);
    bytes[8] = 0x80 | (bytes[8]! & 0x3f);
    const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/**
 * The address a project is given when its author has not chosen one.
 *
 * Every project needs an address from its first save, because that address is what identifies it:
 * the browser's caches and the opener's recorded decisions are filed under it. Nothing is served
 * there until the author actually publishes, and that is fine — the point is that the name does
 * not have to change if they ever do.
 *
 * So this address is deliberately opaque. A readable one would be derived from the title and
 * would change when the title changed, filing one work under a second name. Readability belongs
 * to the deliberate act of publishing, where the author names the address themselves; a list that
 * has to be read by a person shows the project's title beside this.
 *
 * The two directory levels divide the projects so that no single directory grows without bound,
 * and they are taken from the **end** of the UUID. A version 7 UUID begins with the top of a
 * millisecond clock, which barely moves, so sharding on its first characters would put every
 * project ever created in one directory. The last characters are the random half.
 * @param {string} origin Where the editor that assigns this is served from; it claims no other host.
 * @param {string} uuid A version 7 UUID, from createProjectUUID.
 * @returns {string} The absolute HTTPS address.
 */
export function defaultProjectURI(origin: string, uuid: string): string {
    if (!UUIDV7.test(uuid)) fail('INVALID_PROJECT_URI', 'A version 7 UUID is required');
    let base: URL;
    try { base = new URL(origin); } catch { fail('INVALID_PROJECT_URI', 'An absolute origin is required'); }
    if (base.protocol !== 'https:' || base.username || base.password) {
        fail('INVALID_PROJECT_URI', 'A project origin must be HTTPS without credentials');
    }
    const tail = uuid.replaceAll('-', '').slice(-4);
    const path = `${base.pathname.replace(/\/*$/, '')}/${PROJECT_URI_PREFIX}/${tail.slice(0, 2)}/${tail}/${uuid}.sb3`;
    return new URL(path, base.origin).href;
}
