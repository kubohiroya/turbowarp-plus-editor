# Editor Windows

#151 の段階4で使う独立 React パッケージ。タイトルバーと、別画面で開く、最小化、最大化／復元、閉じる（ドック）の操作ボタンを提供する。

`WindowTitleBar` の `target` と `titleContent` にはホストから React 要素を渡せる。たとえば `editor-views` の対象コンボボックスと編集タブを組み合わせる。各ボタンは操作をコールバックで通知し、最大化の状態はホストから受け取る。

最小化・最大化・閉じるボタンは `windowControls` に渡す。既定の `presentation="internal"` で表示される。標準のウィンドウ枠を持つ別ウィンドウでは `presentation="external"` を渡し、ネイティブの操作を使う。対象やタブは両方で表示できる。

```jsx
import {
    WindowTitleBar, OpenWindowButton, MinimizeWindowButton, MaximizeWindowButton, DockWindowButton
} from '@kubohiroya/turbowarp-editor-windows';
import '@kubohiroya/turbowarp-editor-windows/styles.css';

<WindowTitleBar title="コード" target={targetSelector} windowControls={<>
    <MinimizeWindowButton label="最小化" onMinimize={minimize} />
    <MaximizeWindowButton maximized={maximized} onChange={setMaximized} />
    <DockWindowButton label="閉じる（ドックに戻す）" onDock={dock} />
</>}>
    <OpenWindowButton label="別画面で開く" onOpen={open} />
</WindowTitleBar>
```

## ローカル検証

```sh
npm ci
npx playwright install chromium
npm test
```

`npm run build` と `npm run build:fixture` の後、`fixture-dist/index.html` で日本語のタイトルバーと操作通知を確認できる。

## アプリ内ウィンドウ

`WindowDesktop` はエディターの作業領域に配置する。`useWindowHost()` が返す `open({id, title, openExternal})` は、内容をポータルで表示するマウント先、閉鎖通知、終了操作を提供する。同じ ID の基本画面は同時に1つ。ヘッダーやリサイズグリップのドラッグと矢印キーで移動・サイズ変更できる。`WindowList` を作業領域内の固定ツールバーに置くと、最小化した画面を戻せる。最大化は作業領域内に収まる。
