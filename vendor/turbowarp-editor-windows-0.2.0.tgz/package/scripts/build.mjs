import {build} from 'esbuild';
import {copyFile, mkdir} from 'node:fs/promises';

await mkdir('dist', {recursive: true});
const options = {
    entryPoints: ['src/index.jsx'],
    bundle: true,
    external: ['react'],
    target: 'es2018'
};
await Promise.all([
    build({...options, format: 'esm', outfile: 'dist/index.js'}),
    build({...options, format: 'cjs', outfile: 'dist/index.cjs'}),
    copyFile('src/styles.css', 'dist/styles.css'),
    copyFile('src/index.d.ts', 'dist/index.d.ts')
]);
