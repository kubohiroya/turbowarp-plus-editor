import React from 'react';
import {isMacPlatform, projectReplaceOpener, projectReplaceShortcut} from '@kubohiroya/turbowarp-plus-editor-project-model/project-search-connections';
import type {SearchProject} from '@kubohiroya/turbowarp-plus-editor-project-model/project-search';

interface Workspace {
    options: {readOnly: boolean};
    getParentSvg(): SVGElement;
    hasUndoStack(): boolean;
    hasRedoStack(): boolean;
    isDragging(): boolean;
    isVisible(): boolean;
    targetWorkspace?: Workspace;
    isFlyout: boolean;
}

interface WorkspaceContext {
    vm: object;
    workspace: Workspace;
    canUse(): boolean;
    ScratchBlocks: {
        getMainWorkspace(): Workspace;
        selected?: {workspace: Workspace; isDeletable(): boolean; isMovable(): boolean};
        clipboardXml_?: unknown;
        clipboardSource_?: Workspace;
        onKeyDown_(event: Pick<KeyboardEvent, 'target' | 'keyCode' | 'ctrlKey' | 'shiftKey' | 'preventDefault'>): void;
    };
}

interface MenuProps {
    vm: {runtime?: SearchProject};
    locale: string;
    MenuItem: React.ComponentType<{className?: string; children: React.ReactNode}>;
    MenuSection: React.ComponentType<{children: React.ReactNode}>;
    renderIcon(command: Command | 'restoreDeletion'): React.ReactNode;
    getRearrangement?(): {canArrange(): boolean; open(locale: string): void} | undefined;
    onRequestClose(): void;
}

const workspaces = new WeakMap<object, WorkspaceContext>();

export function attachEditMenuWorkspace(context: WorkspaceContext) {
    workspaces.set(context.vm, context);
    return {dispose() {
        if (workspaces.get(context.vm) === context) workspaces.delete(context.vm);
    }};
}

const groups = [
    [['undo', 'Undo', '元に戻す'], ['redo', 'Redo', '繰り返し']],
    [['cut', 'Cut', '切り取り'], ['copy', 'Copy', 'コピー'], ['paste', 'Paste', '貼り付け']],
    [['findAndReplace', 'Find and Replace', '検索と置換'],
        ['cleanup', 'Rearrange Code Blocks', 'コードブロックの再配置']]
] as const;

type Command = (typeof groups)[number][number][0];
const shortcutKeys = {undo: 'Z', redo: 'Y', cut: 'X', copy: 'C', paste: 'V'};

function shortcutFor(command: Command, mac: boolean) {
    if (command === 'cleanup') return;
    if (command === 'findAndReplace') {
        const {label, macLabel, keys, macKeys} = projectReplaceShortcut;
        return {label: mac ? macLabel : label, keys: mac ? macKeys : keys};
    }
    if (mac && command === 'redo') return {label: '⇧⌘Z', keys: 'Meta+Shift+Z'};
    const key = shortcutKeys[command];
    return mac ? {label: `⌘${key}`, keys: `Meta+${key}`} : {label: `Ctrl+${key}`, keys: `Control+${key}`};
}

function canRun(context: WorkspaceContext | undefined, command: Exclude<Command, 'findAndReplace' | 'cleanup'>): boolean {
    if (!context?.canUse()) return false;
    const {workspace, ScratchBlocks} = context;
    if (ScratchBlocks.getMainWorkspace() !== workspace || workspace.options.readOnly ||
        !workspace.isVisible() || workspace.isDragging() || workspace.getParentSvg().closest('[inert]')) return false;

    if (command === 'undo') return workspace.hasUndoStack();
    if (command === 'redo') return workspace.hasRedoStack();
    if (command === 'paste') {
        const source = ScratchBlocks.clipboardSource_;
        return Boolean(ScratchBlocks.clipboardXml_) && (source?.isFlyout ? source.targetWorkspace : source) === workspace;
    }

    const block = ScratchBlocks.selected;
    return Boolean(block?.isDeletable() && block.isMovable() && (block.workspace === workspace ||
        (command === 'copy' && block.workspace.isFlyout && block.workspace.targetWorkspace === workspace)));
}

export function renderEditMenu(props: MenuProps) {
    return <EditMenu {...props} />;
}

export function renderEditMenuRestore(label: React.ReactNode, renderIcon: MenuProps['renderIcon']) {
    return <span className="tw-edit-menu__restore">{renderIcon('restoreDeletion')}{label}</span>;
}

function EditMenu({vm, locale, MenuItem, MenuSection, renderIcon, onRequestClose, getRearrangement}: MenuProps) {
    const japanese = /^ja(?:-|$)/i.test(locale);
    const mac = isMacPlatform();
    const context = workspaces.get(vm);
    const openReplace = projectReplaceOpener(vm.runtime);
    const rearrangement = getRearrangement?.();
    return <>{groups.map(group => <MenuSection key={group[0][0]}>
        {group.map(([command, english, translated]) => {
            if (command === 'cleanup' && !getRearrangement) return null;
            const shortcut = shortcutFor(command, mac);
            const enabled = command === 'cleanup' ? rearrangement?.canArrange() :
                command === 'findAndReplace' ? Boolean(openReplace) : canRun(context, command);
            return <MenuItem key={command}>
                <button className="tw-edit-menu__command" type="button"
                    disabled={!enabled}
                    aria-keyshortcuts={shortcut?.keys} onClick={event => {
                        if (command === 'cleanup') {
                            const current = getRearrangement?.();
                            if (!current?.canArrange()) return;
                            onRequestClose();
                            current.open(locale);
                            return;
                        }
                        if (command === 'findAndReplace') {
                            if (!openReplace) return;
                            onRequestClose();
                            openReplace();
                            return;
                        }
                        const current = workspaces.get(vm);
                        if (!canRun(current, command)) return;
                        // Keep cut, copy and paste on the same ScratchBlocks clipboard.
                        current.ScratchBlocks.onKeyDown_({target: event.currentTarget,
                            keyCode: shortcutKeys[command].charCodeAt(0), ctrlKey: true, shiftKey: false,
                            preventDefault: () => event.preventDefault()});
                        onRequestClose();
                    }}>
                    {renderIcon(command)}
                    <span>{japanese ? translated : english}</span>
                    {shortcut && <kbd className="tw-edit-menu__shortcut" aria-hidden="true">{shortcut.label}</kbd>}
                </button>
            </MenuItem>;
        })}
    </MenuSection>)}</>;
}
