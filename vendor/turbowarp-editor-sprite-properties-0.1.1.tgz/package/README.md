# スプライト設定パネル

TurboWarp Plus Editor の #175 向け React パッケージ。名称、x、y、可視性、大きさ、向き、回転方法を編集する。Editor や scratch-gui を起動せずにビルド・検証できる。

## 組み込み

```jsx
import {SpritePropertiesPanel} from '@kubohiroya/turbowarp-editor-sprite-properties';
import '@kubohiroya/turbowarp-editor-sprite-properties/styles.css';

<SpritePropertiesPanel
    targetId={sprite?.id ?? null}
    values={sprite}
    locale={locale}
    disabled={readOnly}
    onChange={(id, patch) => updateSprite(id, patch)}
/>
```

ホストは対象 ID と現在値を管理し、変更先の ID を検証して `patch` を反映する。コールバックは確定した1項目を返す。対象を選択していない場合やステージを選択した場合は `targetId` に `null` を渡す。読み取り専用の場合は `disabled` を渡す。

入力は Enter またはフォーカスを離れたときに確定する。既存の設定欄に合わせて数値の表示は整数に丸め、確定値は入力された数値を渡す。空の数値欄の確定値は 0 になる。対象を切り替えた時点で確定していない入力は破棄する。パネルの幅による配置変更は入力とフォーカスを保つ。

## ローカル検証

```sh
npm ci
npx playwright install chromium
npm test
```

`npm run build:fixture` は `npm run build` 済みのパッケージから独立した検証画面 `fixture-dist/index.html` を生成する。ブラウザーで開き、上部のコントロールからパネルの幅と高さ、言語、対象を変更できる。
