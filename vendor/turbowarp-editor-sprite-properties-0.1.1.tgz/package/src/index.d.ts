import type {ReactElement} from 'react';

export interface SpriteProperties {
    name: string;
    x: number;
    y: number;
    visible: boolean;
    size: number;
    direction: number;
    rotationStyle: 'all around' | 'left-right' | "don't rotate";
}

export interface SpritePropertiesPanelProps {
    targetId: string | null;
    values?: Partial<SpriteProperties>;
    disabled?: boolean;
    locale?: string;
    onChange(targetId: string, patch: Partial<SpriteProperties>): void;
}

export function SpritePropertiesPanel(props: SpritePropertiesPanelProps): ReactElement;
