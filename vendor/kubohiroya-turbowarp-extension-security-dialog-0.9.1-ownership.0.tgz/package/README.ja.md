# @kubohiroya/turbowarp-extension-security-dialog

作品の機能拡張をどこまで動かすかを尋ねる1つの画面と、拡張のコードが動き出す前にそれを人の前へ
出すための配線です。

[MPL-2.0](LICENSE) です。「Incompatible With Secondary Licenses」の表示を付けていないので、
GPL-3.0 で配布する大きな作品に組み込めます。TurboWarp-Plus-Editor はそうやって配信しています。

0.8.5は、閉じられる注意表示、選択欄の配置、紹介・リリース・連絡先リンク、概要の改行、
常時表示の追加/キャンセルボタンと、実行・保存方法のアイコンを含むnpm公開版です。
詳細と互換性・切戻しは[0.8.5の公開記録](https://github.com/kubohiroya/turbowarp-extension-security-dialog/blob/v0.8.5/docs/releases/0.8.5.ja.md)を参照してください。

## 何を解決するか

VM は機能拡張を1つずつ読み込み、そのたびに尋ねます。作品を開くことが確認の行列になり、最後の
拡張を見る前に最初の拡張が動き出します。拡張を追加するときは二度尋ねます。一覧で選んだあとに、
同じことをもう一度訊かれます。

このパッケージは作品全体をまとめて集め、1つの問いにして、そのあとで読み込みます。

## 公開 Editor の拡張確認画面

2026年11月6日に、共通ダイアログ 0.8.5 が配信されている
[公開 TurboWarp Plus Editor](https://kubohiroya.github.io/turbowarp-plus-editor/editor.html?lang=ja) で撮影しました。

**機能拡張を追加する。** TurboWarp Plus カタログで TurboWarp-Title-Menu を選ぶと、
サンドボックスなしで実行する場合の注意が出ます。拡張の行には読み込み元のアイコンと、
拡張の紹介・リリース・製作者の連絡先へのリンクがあります。一覧をスクロールしても
「キャンセル」「追加」は下部に表示され、注意を閉じても選択は残ります。

![TurboWarp-Title-Menu を選択した公開カタログ。閉じられる注意と固定のキャンセル・追加ボタンを表示](./assets/screenshots/public-review-add-ja-20261106.png)

**作品を開く。** この SB3 には Camera Source 0.19.4、Asset Cache 0.3.2、Bubble 0.13.5 を
`data:` URL として保存しています。3件ともサンドボックスなしを必須と申告しているため、
実行方法はその選択肢だけが選択済みになり、OK またはキャンセルを待ちます。
図版の時点では、どの拡張もまだ実行していません。

![公開 Editor の作品を開く確認画面。3件の必須拡張でサンドボックスなしを選択済み](./assets/screenshots/public-review-open-ja-20261106.png)

配信リビジョン、配布物の整合性、画像のハッシュ、日英の操作確認は
[撮影記録](./assets/screenshots/public-review-20261106.json)に記載しています。
[英語版 README](./README.md) にも同じ画面を掲載しています。

## 入口

| import | 中身 |
| --- | --- |
| `.` | カタログの読み込み、拡張自身の申告の読み取り、依存の閉包、開く人の選択の記憶、取得待ちのダイアログ、文言 |
| `./react` | 画面そのもの `ExtensionReview` と、一覧の1行 `ExtensionRow` |
| `./turbowarp` | VM を包んで問いを先に出す `installBatchExtensionLoader` |
| `./styles.css`、`./webpack4.css` | 画面のスタイル。後者は CSS modules 向けにクラス名を `:global()` で包んだもの |

## 画面

```tsx
import {ExtensionReview} from '@kubohiroya/turbowarp-extension-security-dialog/react';
import '@kubohiroya/turbowarp-extension-security-dialog/styles.css';

<ExtensionReview
    mode="open"             // または "add"
    entries={entries}
    locale="ja"
    DialogFrame={HostModal} // 開くときだけ使う
    loadInfo={loadExtensionInfo}
    onComplete={decisions => {/* Map。断られたときは null */}}
/>
```

追加と開くで違うのは、一覧に何が載るかと何を選べるかだけで、問いの立て方は同じです。だから
1つの部品です。

| | `add` | `open` |
| --- | --- | --- |
| 一覧に載るもの | カタログの拡張。依存先は自動で選ばれる | 作品が使う拡張すべて |
| 選ぶ | チェックで選ぶ | 無し。作品が既に名指ししている |
| 動かし方 | サンドボックスの中で、またはサンドボックスなしで | 動かさない、サンドボックスの中で、サンドボックスなしで |
| 読み込み元 | 4つの持ち方から選ぶ | `remote-cacheable` の行でキャッシュを残すかだけ。ほかの行は読み込み元を述べる |
| 一括指定 | 両方 | 動かし方と、断れるキャッシュが1つでもあるときはそのキャッシュ |

### 4つの持ち方

拡張のバイト列の持ち方は4つです。ローダーの Manifest・SB3 の保存形式・この画面が同じ語で呼ぶので、
ホストは両端を変換表なしでつなげます。

| 名前 | このブラウザー | 作品のファイル | 標準 TurboWarp |
| --- | --- | --- | --- |
| `remote-non-cacheable` | 何も残さない | 参照だけ | 開けない |
| `remote-cacheable` | 検証したキャッシュを残してよい | 参照だけ | 開けない |
| `embedded-file` | 残すものが無い | バイト列を ZIP の中のファイルとして持つ | 開けない |
| `embedded-data` | 残すものが無い | バイト列を `data:` の値として持つ | **開ける** |

**4つはすべて作者の決定**で、拡張を追加したときに決まります。だから `add` は4つすべてを出し、
`open` はほとんど何も出しません。開く人に残る問いは「`remote-cacheable` の行のキャッシュを自分の
ブラウザーに実際に残すか」だけで、しかも**断ることしかできません**。`remote-non-cacheable` は
作者がキャッシュを禁じたということで、それを上書きして許可を書く書き方は存在しません。そのため
`loadingChoices` は行の source から選択肢を読み取り、横に対応表を置く必要がありません。source が
持ち方を名指している行はもうそのように読み込まれているので、画面は尋ねるのではなく述べます。

### 実行方法・信頼済みの拡張・記憶した選択

**作品を開くとき、全件がサンドボックスなしを必須と申告していれば、そのモードを選択済みにします。**
取得失敗がなく、空でない一覧のすべての申告が揃った場合だけ適用します。「動かさない」と
「サンドボックスの中で」、実行方法の一括指定は表示しません。OKで実行を承認するか、キャンセルで
中止します。OK前には実行しません。読み込み元やキャッシュを断る選択は別に保ちます。

カタログからの追加、通常・未申告・任意指定・取得失敗が混ざる作品では、従来どおり
サンドボックスの中を既定にし、実行方法を選べます。必須の申告に反する選択は警告します。

追加画面の各行は、左からチェックボックス、アイコン、拡張名の順に並べます。
名前やアイコンをクリックしても選択できます。

「キャンセル」「追加」はダイアログ下部に常時表示します。案内・一括設定・一覧の領域だけを
スクロールするので、最下部まで移動せずに追加やキャンセルができます。注意のスナックバーは
操作ボタンの上に表示し、ボタンを覆いません。

タイトル行の信頼済みアイコンは、登録された紹介ページ（`docsURL`）を別タブで開きます。
バージョン表記は、GitHubリポジトリの該当する `v{version}` リリースノートへリンクします。
紹介ページ・リポジトリ・バージョンの情報が不足する場合は、リンクを付けずに表示します。
概要は改行を保持し、HTTP(S) URL、`mailto:`、メールアドレスをリンクとして表示します。
製作者名の右横には、登録済みの連絡先（`authorURL`）を表示します。HTTP(S)と`mailto:`に対応し、
連絡先がなければ省略します。HTMLは文字として表示し、リンクの操作で拡張の選択は変わりません。

サンドボックスなしで動く拡張を選ぶと、画面下部にスナックバーで注意を表示します。
一覧やスクロール位置は動かず、明暗どちらのテーマでも濃紺の背景と白い文字で表示します。
自動では消えず、「閉じる」で非表示にしても選択や許可は変わりません。警告が必要な選択を
すべて解除するまでは閉じた状態を保ち、再び選択したときは表示し直します。

**信頼済みかどうかはホストが決めます。** `entry.state.trusted` を指定した行には信頼済みの印を付け、
サンドボックスなしを適用します。すべての行が信頼済みの作品では、ホストは `requiresReview` で確認を
省略できます。

**記録された答えは、いまも選択肢である場合だけ尊重します。** 作品が `remote-cacheable` から
埋め込みに変わった、行が信頼済みになった、といった場合に、もう提示しない答えを持ち込みません。

### 一覧の1行だけを使う

`ExtensionRow` は、画面の各行と同じ1行を描きます。拡張の名前（チェックボックス付きも可）、ID、信頼済みの印、版とリリースノートへのリンク、画像、概要、製作者と連絡先です。ほかの画面で機能拡張を並べるときにも、拡張が同じ見た目になります。TurboWarp Plus Editor では、ブロックパレットの表示を選ぶ画面が使います。

```tsx
import {ExtensionRow} from '@kubohiroya/turbowarp-extension-security-dialog/react';
import '@kubohiroya/turbowarp-extension-security-dialog/styles.css';

<ul>
    <ExtensionRow
        metadata={{name: 'Pen Plus', author: 'Creator', version: '2.0.0'}}
        ids={['penplus']}
        locale="ja"
        pick={{checked: shown, onToggle: () => setShown(!shown)}}  // 省くとチェックボックスなし
        itemProps={{'data-key': 'penplus'}}
    >
        {/* 製作者の下に、ホスト自身の内容を置く */}
    </ExtensionRow>
</ul>
```

`details` は見出しと画像のあいだに置く内容で、確認画面は読み込み元とダイジェストをここに出します。`children` は製作者の下に置く内容で、確認画面は実行方法と読み込み元の選択をここに出します。行は `<li>` なので、`<ul>` か `<ol>` の中に置きます。`pick.disabled` のときは、チェックボックスも画像も選択を変えません。

### 読み込みに失敗したとき

```tsx
<ExtensionReview
    /* ...上と同じ */
    failure={{code: error.code, message: error.message, retryable: isWorthAskingAgain(error)}}
    onRetry={() => loadAgain()}
/>
```

`failure` は読み込み全体の失敗で、行の一覧の上に出ます。行ごとの失敗は行の `state.error` に入れ、
こちらも同じ `retryable` を任意で持てます。どちらも同じ規則に従います。

| `retryable` | `onRetry` | 画面に出るもの |
| --- | --- | --- |
| `true` | 渡されている | コードとメッセージ、「通信の問題の可能性があります」、`onRetry` を呼ぶ **もう一度試す** ボタン |
| `true` | 渡されていない | コードとメッセージだけ |
| `false` または無し | どちらでも | コードとメッセージだけ |

`failure` を渡さなければ、これらの props が無かったときとまったく同じに描きます。
必須なのは `message` だけです。`failure={{message: '取得できませんでした'}}` なら失敗の文だけを
表示します。`code` は表示用の任意の値で、`retryable` を省略した場合はやり直しを提示しません。

公開パッケージには `dist/build-info.json` を含め、
`@kubohiroya/turbowarp-extension-security-dialog/build-info` からも参照できます。`name`、`version`、
ソースの完全な `revision`、`sourceState`（`commit`、`working-tree`、`git-archive`）を記録します。ホスト側は
完全版を固定し、配信前に revision を照合できます。切り戻しはパッケージ版と lockfile を元に戻す
ことで行えます。新しい失敗表示だけを止める場合は、`failure` と `onRetry` を渡さないでください。

**画面はエラーコードの表を持ちません。** もう一度試して結果が変わりうるかはホストの判断で、
TurboWarp-Plus Editor ではローダーの `isWorthAskingAgain` が決め、真偽値として渡されます。コード
では決まりません。`LOAD_FAILED` は、もう一度試せば通るかもしれない通信の切断からも、何度試しても
通らない「登録した ID が違う」拡張からも出ます。後者に「もう一度試す」を出すのは、画面が裏付け
られない助言です。

## 取得を待つあいだ

```js
import {createExtensionWaitDialog} from '@kubohiroya/turbowarp-extension-security-dialog';

const wait = createExtensionWaitDialog(document, locale);
// ローダーが再試行を報告します。待ちが現実のものになった時点で show() が開きます。
const ports = createFetchPort(fetch, {onRetry: info => wait.show(info)});
// 成否どちらの経路でも hide() を呼びます。ホストが消えるときは dispose() です。
```

1つの拡張の取得が、通信のやり直しで数秒止まることがあります。そのあいだ操作全体が止まります
——どの行も検証と承認を終えるまで、1つも登録されません。だから隅ではなく画面の中央を取ります。
このあとに出る問いも同じ場所に出るので、注意を動かさずに済みます。

**閉じるボタンもキャンセルボタンもありません。** 意図的にそうしています。閉じても取得は止まらず、
途中で止めてもロールバックの実装がまだ無いので、どちらのボタンも存在しない制御を差し出すことに
なり、何も戻せない状態を作りかねません。Escape を断るのも同じ理由です。

表示は `delayMs`（既定 300ms）だけ遅れます。最短の待ちは1回のバックオフなので、0.5秒で現れて
消えるダイアログはちらつきとしか読めず、何のためでもなくフォーカスを奪います。スタイルは自前で
持ち、1つの document につき一度だけ注入します。すべてのホストが CSS のパイプラインを持っている
わけではなく、単一 HTML のランタイムやパッケージャーのページは JavaScript だけを組み立てます。

## VM への配線

```js
import {installBatchExtensionLoader} from '@kubohiroya/turbowarp-extension-security-dialog/turbowarp';
import {createDecisionStorage} from '@kubohiroya/turbowarp-extension-security-dialog';

const uninstall = installBatchExtensionLoader(vm, review, defaultURLs, createDecisionStorage(), {
    collectEntries: async project => /* ホストが持つ行。例: Plus の Manifest */ [],
    applyDecisions: decisions => /* 同じ答えからローダーの信頼とキャッシュを動かす */ {},
    identify: async project => /* このホストが作品をどう名指すか */ null
});
```

この層が自分で読み込むのは、従来のカスタム拡張だけです。ホストが集めた行は、それを取得・検証した
もの（TurboWarp-Plus-Editor ではローダー）のものなので、`collectEntries` で入って
`applyDecisions` で出ていきます。このパッケージはローダーの型もコードも参照しません。依存は
一方向で、こちらが口を定義し、ホストが実装します。

断られた場合は `onComplete` が `null` を返し、読み込みは `isExtensionSecurityCancelled` が
見分けられるエラーで止まります。ホストは拒否と不具合を取り違えません。

## 何を、どこに覚えるか

| 内容 | 場所 | 決める人 |
| --- | --- | --- |
| 4つの持ち方のどれか | 作品 | 追加した人 |
| 動かし方（追加したとき） | 作品 | 追加した人 |
| 動かし方（開いたとき） | このブラウザー、作品ごと | 開く人 |
| `remote-cacheable` のキャッシュを実際に残すか | このブラウザー、作品ごと | 開く人。断ることだけできる |
| プレビュー画像 | このブラウザー | 誰でもない。常に残す |

保存が使えないとき（プライベートウィンドウ、サイトデータを止めたブラウザー）も、読み取りは必ず
使える値を返します。これを土台にした画面が開けなくなることはありません。

## 主張しないこと

名前・製作者・バージョン・ライセンスは、いずれも拡張が自分の先頭コメントに書いた言葉です。画面は
それを未検証の申告として示します。ここでコードを評価することはありません。プレビュー画像は装飾で、
何とも照合していません。コードを検証するのは別の場所で、失敗した行にはそう表示されます。

先頭コメントは2つの書き方を読みます。TurboWarp 本体の拡張とギャラリーが使う `// Name: ...` の行と、`/** @name ... */` のブロックです。同じ項目を両方が書いていればブロックを採ります。見出しとして読むのは先頭に続くコメント行だけで、`Bundled extensions:` で止めます。バンドルが中身について書いたことは中身のもので、バンドル自身のものではないためです。

## 開発

```sh
pnpm install
pnpm run typecheck
pnpm run check   # ビルド、単体テスト、pack の dry run
node --test test/wait.browser.ts test/review.browser.ts # 取得待ち・選択画面の実ブラウザ検証
```

React と React DOM は peerDependencies なので、ホストが用意します。実行時の依存はありません。

## ライセンス

[MPL-2.0](LICENSE)。何が対象で何が対象外かは [NOTICE.md](./NOTICE.md) を参照してください。

0.6.0でMPL-2.0へ書き直したときの設計の記録は [書き直しの設計](docs/mpl-rewrite.ja.md) にあります。

npmが固定したGitHubアーカイブを`.git`なしでビルドする場合、インストーラーはlockfileと同じ完全SHAを`TWEXTSEC_SOURCE_REVISION`で渡します。`sourceState: "git-archive"`として記録し、完全SHAがなければビルドを拒否します。ホストはインストール後の記録をmanifest・lockfileと照合します。

## Editor の実装との責務分担

Editor 独自実装の移管元とライセンス確認は [EDITOR-MIGRATION.md](EDITOR-MIGRATION.md) に記録しています。
追加した公開 API は GUI モジュールを import せず、ホストから必要な値・データ・コールバックを受け取ります。
