import {defineConfig} from 'vite';

export default defineConfig({
    resolve: {alias: {buffer: 'buffer/'}},
    build: {
        target: 'es2017',
        license: {fileName: 'THIRD_PARTY_NOTICES.md'},
        lib: {
            entry: {index: 'src/browser.ts', repository: 'src/repository.ts'},
            formats: ['es'],
            fileName: (_format, name) => `${name}.js`,
            cssFileName: 'style'
        },
        rolldownOptions: {external: ['react', 'react-dom']}
    }
});
